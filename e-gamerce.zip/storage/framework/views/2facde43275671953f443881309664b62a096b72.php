<?php $__env->startSection('title', 'Games'); ?>
<?php $__env->startSection('content'); ?>

<div class="pcoded-main-container">
    <div class="pcoded-wrapper">
        <div class="pcoded-content">
            <div class="pcoded-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>All Games</h5>
                                        <div class="float-right">
                                            <a class="btn  btn-primary text-white" href="<?php echo e(route('games.create')); ?>">Add New Game</a>
                                        </div>
                                        </div>
                                    <div class="card-body">
                                        <div class="dt-responsive table-responsive">
                                            <table id="simpletable" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Title</th>
                                                        <th>Image</th>
                                                        <th>Description</th>
                                                        <th>Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($game->title); ?></td>
                                                        <td><img src="<?php echo e(asset($game->image)); ?>" alt="" srcset="" width="50px" height="50px"></td>
                                                        <td><?php echo e(is_null($game->description) ? 'Null' : $game->description); ?></td>
                                                        <td class="d-inline-flex">
                                                            <a type="button" class="btn btn-icon btn-outline-success" href="<?php echo e(route('games.edit',$game->id)); ?>"><i class="feather icon-edit"></i></a>
                                                            <form action="<?php echo e(route('games.destroy',$game->id)); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="_method" value="DELETE">
                                                                <button type="button" class="btn btn-icon btn-outline-danger"><i class="feather icon-trash"></i></button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center">No Record Found</td>
                                                    </tr>
                                                    <?php endif; ?>


                                                </tbody>


                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>



                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
       // delete player
       $(document).on('click', ".delete", function() {
            let status = $(this).data('status');
            status = parseInt(status);
            switch (status) {
                case 1:
                    btn_txt = 'Completed!';
                    break;
                case 2:
                    btn_txt = 'Cancel!';
                    break;
                default:
                    btn_txt = 'Continue!';
                    break;
            }
            Swal.fire({
                    title: "Are you sure?",
                    text: "You want Delete This Player!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: `${btn_txt}`
                })
                .then((result) => {
                    if (result.value) {
                        let id = $(this).data('id');
                        window.location = "/delete-players/"  + id;
                    } else {
                        Swal.fire(
                            'Cancelled!',
                            'Operation Cancelled!',
                            'info'
                        )
                    }
                });
        });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\e-gamerce\resources\views/admin/games/index.blade.php ENDPATH**/ ?>